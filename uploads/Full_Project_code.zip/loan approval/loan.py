import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.impute import SimpleImputer

# Load the dataset to inspect its structure
loan_data = pd.read_csv(r'C:\Users\naray\Downloads\LoanApprovalPrediction.csv')
print(loan_data)
# Display the first few rows of the dataset to understand its structure
print(loan_data.head())
print(loan_data['Loan_Status'].value_counts())
print(loan_data.isna().sum())

loan_data.dropna(subset=['LoanAmount','Loan_Amount_Term','Credit_History','Gender','Married','Dependents','Self_Employed'], inplace=True)
print(loan_data.isna().sum())

# Encoding categorical variables
label_encoder = LabelEncoder()
loan_data['Gender'] = label_encoder.fit_transform(loan_data['Gender'])
loan_data['Married'] = label_encoder.fit_transform(loan_data['Married'])
loan_data['Education'] = label_encoder.fit_transform(loan_data['Education'])
loan_data['Self_Employed'] = label_encoder.fit_transform(loan_data['Self_Employed'])
loan_data['Property_Area'] = label_encoder.fit_transform(loan_data['Property_Area'])
loan_data['Loan_Status'] = label_encoder.fit_transform(loan_data['Loan_Status'])

# Defining features (X) and target (y)
X = loan_data.drop(columns=['Loan_ID', 'Loan_Status'])
y = loan_data['Loan_Status']

print(X)
print(y)

# Splitting the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

print(X.shape,X_train.shape,X_test.shape,y.shape,y_test.shape,y_train.shape)

from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Scaling the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Logistic Regression with increased max_iter
log_reg = LogisticRegression(max_iter=500)
log_reg.fit(X_train_scaled, y_train)
y_pred_log_reg = log_reg.predict(X_test_scaled)

# Decision Tree
decision_tree = DecisionTreeClassifier()
decision_tree.fit(X_train, y_train)
y_pred_tree = decision_tree.predict(X_test)

# Evaluate the models
log_reg_accuracy = accuracy_score(y_test, y_pred_log_reg)
tree_accuracy = accuracy_score(y_test, y_pred_tree)

print(f"Logistic Regression Accuracy: {log_reg_accuracy * 100:.2f}%")
print(f"Decision Tree Accuracy: {tree_accuracy * 100:.2f}%")


import pickle

# Save the logistic regression model
with open('scaler.pkl', 'wb') as file:
    pickle.dump(scaler, file)
    
scaler = pickle.load(open('scaler.pkl', 'rb'))
# Save the logistic regression model
with open('logistic_regression_model.pkl', 'wb') as file:
    pickle.dump(log_reg, file)
    